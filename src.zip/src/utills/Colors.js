const Colors = {
    Appthemecolor:'#FF9727',
    alertColor:'red',
    activeinputs:'#F9A828',
    border:'#ECECEB',
    carttextcolor:'#4A4B4D',
    inputtextcolor:'rgba(26, 26, 26, 0.56)',
    inputbordercolor:'rgba(26, 26, 26, 0.25)',
    dargrey:"#181E25",
    appgreycolor:'#A4A4A4',
    inputcolor:'#00000008'
        };
        export default Colors;
        
        
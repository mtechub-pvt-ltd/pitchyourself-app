import React from 'react';
import {
  StyleSheet,
} from 'react-native';


const cardcontainerstyles = StyleSheet.create({
  container:
  {
    flex: 1,
    alignContent: 'center',
    backgroundColor:'white'
  },
});
export default cardcontainerstyles;

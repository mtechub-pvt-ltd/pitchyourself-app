//export const BASE_URL = 'https://pitchappadmin.co.uk/';
export const BASE_URL = 'http://192.168.18.20:4000/'

//https://pitchappadmin.co.uk/